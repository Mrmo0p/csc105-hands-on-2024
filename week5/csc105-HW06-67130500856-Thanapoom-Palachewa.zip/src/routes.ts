import { Hono } from 'hono'
import { db } from './db'

const app = new Hono()

app.get('/users', async (c) => {
  const users = await db.user.findMany()
  return c.json(users)
})

app.patch('/todos/:id/complete', async (c) => {
  const id = parseInt(c.req.param('id'))
  const todo = await db.todo.update({
    where: { id },
    data: { complete: true }
  })
  return c.json(todo)
})

app.patch('/todos/:id/title', async (c) => {
  const id = parseInt(c.req.param('id'))
  const body = await c.req.json()
  const todo = await db.todo.update({
    where: { id },
    data: { title: body.title }
  })
  return c.json(todo)
})

app.get('/users/:id/todos', async (c) => {
  const userId = parseInt(c.req.param('id'))
  const todos = await db.todo.findMany({
    where: { userId }
  })
  return c.json(todos)
})

app.patch('/users/:id', async (c) => {
  const id = parseInt(c.req.param('id'))
  const body = await c.req.json()
  const user = await db.user.update({
    where: { id },
    data: {
      firstName: body.firstName,
      lastName: body.lastName
    }
  })
  return c.json(user)
})

export default app
