import { PrismaClient } from './generated/prisma.js'

export const db = new PrismaClient()