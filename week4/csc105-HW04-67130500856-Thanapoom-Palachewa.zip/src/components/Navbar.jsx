import { NavLink } from "react-router-dom";

function Navbar() {
  return (
    <nav className="w-full bg-red-800 text-white p-4 flex justify-center space-x-40">
      <NavLink to="/" end>
        Home
      </NavLink>
      <NavLink to="/Favorites">Favorites</NavLink>
      <NavLink to="/login">Login</NavLink>
    </nav>
  );
}

export default Navbar;
