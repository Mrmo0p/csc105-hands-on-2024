import React from "react";

const HomePage = () => {
  return (
    <>
    <div className="bg-gray-200 border-2">
    <div className="flex justify-center font-bold text-9xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
    <div className="flex justify-center font-bold text-8xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
    <div className="flex justify-center font-bold text-7xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
    <div className="flex justify-center font-bold text-6xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
    <div className="flex justify-center font-bold text-5xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
    <div className="flex justify-center font-bold text-4xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
    <div className="flex justify-center font-bold text-3xl mt-8"> 
      <p>Welcome to the Home Page!</p>
    </div>
    <div className="flex justify-center font-bold text-xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
      <div className="flex justify-center font-bold text-1xl mt-8">
      <p>Welcome to the Home Page!</p>
      </div>
      </div>
      
      </>
  );
};

export default HomePage;
