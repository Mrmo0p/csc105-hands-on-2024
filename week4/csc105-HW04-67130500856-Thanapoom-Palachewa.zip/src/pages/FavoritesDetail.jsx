import React from "react";
import { useParams, useSearchParams } from "react-router-dom";

const FavoritesDetail = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();

  const q = searchParams.get("q") || "N/A";
  const size = searchParams.get("size") || "N/A";

  return (
    <div className="p-6 text-lg">
      <p>
        Your favorites post is <strong>{q}</strong>. Post ID is{" "}
        <strong>{id}</strong>. Size is{" "}
        <strong>{size}</strong>.
      </p>
    </div>
  );
};

export default FavoritesDetail;
