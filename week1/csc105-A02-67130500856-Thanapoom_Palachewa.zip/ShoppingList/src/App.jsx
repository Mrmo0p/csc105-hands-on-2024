import { useState } from "react";

const ShopList = () => {
  const [items, setItems] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [editIndex, setEditIndex] = useState(null);

  const addItem = () => {
    if (inputValue.trim()) {
      if (editIndex !== null) {
        const updatedItems = [...items];
        updatedItems[editIndex].text = inputValue;
        setItems(updatedItems);
        setEditIndex(null);
      } else {
        setItems([...items, { text: inputValue, bought: false }]);
      }
      setInputValue("");
    }
  };

  const toggleBought = (index) => {
    const updatedItems = [...items];
    updatedItems[index].bought = !updatedItems[index].bought;
    setItems(updatedItems);
  };

  const removeItem = (index) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const editItem = (index) => {
    setInputValue(items[index].text);
    setEditIndex(index);
  };

  return (
    <div style={{ 
      display: "flex", 
      flexDirection: "column", 
      alignItems: "center", 
      justifyContent: "center", 
      height: "100vh", 
      width: "100vw", 
      fontFamily: "Arial, sans-serif",
      backgroundColor: "#f5f5f5"
    }}>
      <div style={{ 
        backgroundColor: "white", 
        padding: "20px", 
        borderRadius: "10px", 
        boxShadow: "0px 4px 10px rgba(0, 0, 0, 0.1)", 
        width: "350px", 
        textAlign: "center" 
      }}>
        <h1>Shopping List</h1>
        <div style={{ display: "flex", gap: "10px", marginBottom: "10px", justifyContent: "center" }}>
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Add a new item"
            style={{ padding: "5px", width: "200px", borderRadius: "5px" }}
          />
          <button onClick={addItem} style={{ padding: "5px 10px", backgroundColor: "green", color: "white", borderRadius: "5px" }}>
            {editIndex !== null ? "Update" : "Add"} Item
          </button>
        </div>
        <ul style={{ listStyle: "none", padding: 0, width: "100%" }}>
          {items.map((item, index) => (
            <li
              key={index}
              onClick={() => toggleBought(index)}
              style={{
                textDecoration: item.bought ? "line-through" : "none",
                backgroundColor: item.bought ? "#e8f5e9" : "white",
                cursor: "pointer",
                padding: "10px",
                borderBottom: "1px solid #ccc",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                width: "100%"
              }}
            >
              <span>{item.text}</span>
              <div style={{ display: "flex", gap: "5px" }}>
                <button 
                  onClick={(e) => { e.stopPropagation(); editItem(index); }} 
                  style={{ backgroundColor: 'orange', color: 'black', padding: "5px", borderRadius: "5px" }}
                >
                  Edit
                </button>
                <button 
                  onClick={(e) => { e.stopPropagation(); removeItem(index); }} 
                  style={{ backgroundColor: 'red', color: 'white', padding: "5px", borderRadius: "5px" }}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ShopList;
