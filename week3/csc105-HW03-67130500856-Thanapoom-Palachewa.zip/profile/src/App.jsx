const Profile = () => {
  <title>Profile</title>
  return (
    <>
      <nav className="bg-white p-8">
        <div className="container mx-10 flex justify-between items-center">

          <h1 className="text-2xl font-bold">Tawan Emperor of Mankind</h1>

          {/* nav */}
          <div className="flex space-x-6">
            <a href="#" className="bg-green-200 text-black font-semibold px-4 py-2 rounded-full">
              Home
            </a>
            <a href="#" className="text-black px-4 py-2 font-semibold">About me</a>
            <a href="#" className="text-black px-4 py-2 font-semibold">Gallery</a>
          </div>

          <a href="#" className="bg-green-900 text-white font-semibold px-4 py-2 rounded-full">
            Contact
          </a>
        </div>
      </nav>

      <section className="container mx-auto flex flex-col md:flex-row items-center mt-16 px-6">
        <div className="w-full md:w-1/2 text-center md:text-left">
          <h2 className="text-lg font-semibold">Hello, It's me</h2>
          <h1 className="text-4xl font-bold">Tawan</h1>
          <p className="mt-2 text-gray-600">I am the storm that is approaching provoking black clouds in isolation i am reclaimer of my name.</p>

          {/* Icons */}
          <div className="flex justify-center md:justify-start space-x-4 mt-4">
          </div>

          <button className="mt-6 bg-green-900 text-white px-6 py-3 rounded-full">My Portfolio</button>
        </div>

        <div className="w-full md:w-1/2 flex justify-center">
          <img src="public/tawan_deveil.png-removebg-preview.png" alt="Tawan" className="w-100 rounded-lg"/>
        </div>
      </section>

      <section className="container mx-auto flex flex-col md:flex-row items-center mt-32 px-6">
        <div className="w-full md:w-1/2 flex justify-center">
          <img src="public/tawan_deveil.png-removebg-preview.png" alt="Tawan" className="w-64 rounded-lg"/>
        </div>

        <div className="w-full md:w-1/2 text-center md:text-left">
          <h2 className="text-3xl font-bold">About Me</h2>
          <p className="text-gray-700 mt-4">
          I am reclaimer of my name Born in flames, I have been blessed My family crest is a demon of death Forsakened, I am awakened
          A phoenix's ash in dark divine Descending misery Destiny chasing time.

          </p>
          <button className="mt-6 bg-green-900 text-white px-6 py-3 rounded-full">Read More</button>
        </div>
      </section>

      <section className="container mx-auto mt-32 px-6">
        <h2 className="text-3xl font-bold text-center">Gallery</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <img src="public/tawan aaaa.jpg" alt="Gallery 1" className="rounded-lg"/>
          <img src="public/tawan sigma.jpg" alt="Gallery 2" className="rounded-lg"/>
          <img src="public/tawan.png" alt="Gallery 3" className="rounded-lg"/>
        </div>
      </section>
    </>
  );
};

export default Profile;
